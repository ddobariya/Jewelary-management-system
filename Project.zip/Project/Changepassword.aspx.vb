﻿
Partial Class Changepassword
    Inherits System.Web.UI.Page

End Class
