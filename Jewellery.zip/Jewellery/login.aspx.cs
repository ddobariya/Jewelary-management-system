﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;
public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            uspUser_Validate_Result Obj = user.Validate(txtUser.Text, txtPassword.Text);
            if (Obj == null)
            {
                lblmsg.Text = "Invalid Username or Password.";
            }
            else
            {
                short iUserID = Convert.ToInt16(Obj.iUserID);
                string sName = Obj.Name;
                string sValue = sName + "~" + iUserID.ToString();
                clsCookies.CreateCookie("pa4ss4f0", sValue);
                clsCookies.CreateCookie("pa4ssui", iUserID.ToString());
                //Response.Redirect("../ae_banner.aspx");
            }
        }
        catch (Exception)
        {

            throw;
        }
    }
}