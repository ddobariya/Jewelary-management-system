﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;

public partial class contact : System.Web.UI.Page
{
        protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            pnlThank.Visible = false;
            pnlError.Visible = false;
            Contact_databind();
            //bindMap();
            
        } 
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        
        tblContactU tdata = new tblContactU();
        tdata.sName = txtName.Text;
        tdata.sQuery = txtQuery.Text;
        tdata.sEmail = txtEmail.Text;
        tdata.sPhone = txtContact.Text;
        tdata.sSubject = txtSubject.Text;
        tdata.sType = "Contact";
        int iResult = clsContact.AddContactUs_data(tdata);
        if (iResult == 0)
        {
            pnlContact.Visible = false;
            pnlError.Visible = true;
        }
        else
        {
            pnlContact.Visible = false;
            pnlThank.Visible = true;
        }
    }
    void Contact_databind()
    {
        uspContactdetail_GetById_Result vResult = null;
        vResult = clsContactdetail.Contactdetail_GetById(1);
        lblAddress.Text = vResult.MailingAddress;
        lblPhone.Text = vResult.PhoneNumber;
        lblEmail.Text = vResult.EmailAddress;
    }
}