﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;
using System.Configuration;


public partial class create_account : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        tblUser vResult = new tblUser();
        vResult.Name = txtFname.Text;
        vResult.sUserName = txtUser.Text;
        vResult.sEmailId = txtEmail.Text;
        vResult.sPassword = txtPassword.Text;
        vResult.sMobileNO = txtPhone.Text;
        vResult.sSecurityQuestion = ddlSecurityQue.SelectedIndex.ToString();
        vResult.sAnswer = txtAnswer.Text;
        user.User_Add(vResult);

        

    }
}