﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;
using System.Configuration;
using System.Data;

public partial class ring_list : System.Web.UI.Page
{
    public static int id;
    public static int iCurrent = 1, iTotal, itemp, iRow = 2, iPaging = 10;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            binddata();
            iTotal = clsRing.Ring_GetCount();
            GeneratePage(iCurrent, iTotal);
        }
    }
    void binddata()
    {
        DataTable vResult = clsRing.Ring_GetAll_dev("All", true, 1, iRow, "h.iId");
        //List<uspRing_GetAll_Result> vResult;
        //vResult = clsRing.getall();
        rptRing.DataSource = vResult;
        rptRing.DataBind();
    }
    public void GeneratePage(int iCurrent, int iTotal)
    {
        itemp = iTotal / iRow;
        if (iTotal != (itemp * iRow))
        {
            itemp = itemp + 1;
        }
        int iStart = 1, iEnd = 1;
        DataTable dt = new DataTable();
        dt.Columns.Add("PageNo", typeof(int));
        dt.Columns.Add("PageText", typeof(string));

        if (iTotal > 2)
        {
            //for decide start and end
            if (iCurrent >= iPaging)
            {
                iStart = iCurrent - (iPaging - 1);
            }
            iEnd = iStart + (iPaging - 1);
            if (iEnd > itemp)
            {
                iEnd = itemp;
            }

            //First link
            DataRow dr = dt.NewRow();
            dr["PageNo"] = 1;
            dr["PageText"] = "First";
            dt.Rows.Add(dr);

            //Prev link
            dr = dt.NewRow();
            if (iCurrent > 1)
            {
                dr["PageNo"] = iCurrent - 1;
            }
            else
            {
                dr["PageNo"] = 1;
            }

            dr["PageText"] = "Prev";
            dt.Rows.Add(dr);

            //Pages numbers
            for (int i = iStart; i <= iEnd; i++)
            {
                dr = dt.NewRow();
                dr["PageNo"] = i;
                dr["PageText"] = i.ToString();
                if (i == iCurrent) { dr["PageText"] = "<b>" + i.ToString() + "</b>"; }
                dt.Rows.Add(dr);
            }

            //Next link
            dr = dt.NewRow();
            if (iCurrent + 1 >= itemp)
            {
                dr["PageNo"] = itemp;
            }
            else
            {
                dr["PageNo"] = iCurrent + 1;
            }
            //dr["PageNo"] = iTotal/10;
            dr["PageText"] = "Next";
            dt.Rows.Add(dr);

            //End link
            dr = dt.NewRow();
            dr["PageNo"] = itemp;
            dr["PageText"] = "End";
            dt.Rows.Add(dr);

            //bind to repeator
            //Repeater1.DataSource = dt;
            rptPager.DataSource = dt;
            rptPager.DataBind();
            //Repeater1.DataBind();

            for (int i = 0; i < rptPager.Items.Count; i++)
            {
                ((LinkButton)rptPager.Items[i].FindControl("lnkBtnPager")).Enabled = true;
                string lnkBtnText = ((LinkButton)rptPager.Items[i].FindControl("lnkBtnPager")).Text;
                if (lnkBtnText.Equals("Prev") || lnkBtnText.Equals("First"))
                {
                    if (iCurrent == 1)
                    {
                        ((LinkButton)rptPager.Items[i].FindControl("lnkBtnPager")).Enabled = false;
                    }
                }
                if (lnkBtnText.Equals("Next") || lnkBtnText.Equals("End"))
                {
                    if (iCurrent == (itemp))
                    {
                        ((LinkButton)rptPager.Items[i].FindControl("lnkBtnPager")).Enabled = false;
                    }
                }
                if (lnkBtnText.Equals("<b>" + Convert.ToString(iCurrent) + "</b>"))
                {
                    ((LinkButton)rptPager.Items[i].FindControl("lnkBtnPager")).Enabled = false;
                }
            }
        }
    }
    protected void rptPager_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        iCurrent = Convert.ToInt32(e.CommandArgument);
        Response.Write(iCurrent);

        DataTable dt = clsRing.Ring_GetAll_dev("All", true, 1, iRow, "h.iId");
        if (dt == null)
        {
            Response.Write("in bind data showing error");
        }
        rptRing.DataSource = dt;
        rptRing.DataBind();
        GeneratePage(iCurrent, iTotal);
    }
}