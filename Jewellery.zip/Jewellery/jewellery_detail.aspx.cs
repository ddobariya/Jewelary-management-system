﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;
using System.Configuration;
public partial class jewellery_detail : System.Web.UI.Page
{
    public static int id;
    protected void Page_Load(object sender, EventArgs e)
    {
     id = Convert.ToInt32(Request.QueryString.Get("id").ToString());
        binddata();
    }
    void binddata()
    {
        uspBangles_GetById_Result vResult = null;
        vResult = clsBangels.Bangels_GetById(id);
        lbldescription.Text = vResult.sItemdesc;
        lblDesignNo.Text = vResult.sDesignNo;
        lblcolor.Text = vResult.sColor;
        lbldesingno.Text = vResult.sDesignNo;
       // lblcolor.Text = vResult.sColor;   
        lblgold.Text = vResult.sGold;
       lblCountryorigin.Text = vResult.sCountryOrigin;
        lblweight.Text = vResult.sWeight;
        lblshape.Text = vResult.sShape;
        if (vResult.bDelivery == true)
        {
            lblDelivery.Text = "(Free Delivery)";
        }
        else
        {
            lblDelivery.Text = "";
        }
       // lblcolor.Text = vResult.sColor;
    }
}