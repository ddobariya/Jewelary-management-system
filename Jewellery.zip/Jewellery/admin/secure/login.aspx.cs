﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        try
        {
            if (!IsPostBack)
            {
                this.Form.DefaultButton = this.btnLogin.UniqueID;
                clsCookies.DeleteAllCookie();
            }
        }
        catch (Exception)
        {
            
            throw;
        }


    }
    protected void btnLogin_Click(object sender, EventArgs e)
    {
        try
        {
            uspUser_Validate_Result Obj = user.Validate(txtUsername.Text, txtPassword.Text);
            if (Obj == null)
            {
                lblMsg.Text = "Invalid Username or Password.";
            }
            else
            {
                short iUserID = Convert.ToInt16(Obj.iUserID);
                string sName = Obj.Name;
                string sValue = sName + "~" + iUserID.ToString();
                clsCookies.CreateCookie("pa4ss4f0", sValue);    
                clsCookies.CreateCookie("pa4ssui", iUserID.ToString());
                Response.Redirect("../contact_list.aspx?type=contact");
            }
        }
        catch (Exception)
        {
            
            throw;
        }
           
    }
    
}