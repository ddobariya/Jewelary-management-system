﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;

public partial class login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            
        }
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            uspUser_Get_PassWord_Result Obj = user.Get_PassWord(txtUserName.Text.Trim());
            if (Obj != null)
            {
                string sPassWord = Obj.sPassWord;
                string sBody = "<html><body>Dear $Name$, <br /><br /> Here is your password as per your request. Please save it to the secure location. <br / > Password: $PassWord$ <br/><br/> - Vastu Consultancy</body></html>";
                sBody = sBody.Replace("$Name$", Obj.Name).Replace("$PassWord$", Obj.sPassWord.ToString());
                if (SendEmail(Obj.sEmailId, ConfigurationManager.AppSettings["adminemail"].ToString(), sBody, "Vastu Consulatant - Password Request", true, ""))
                {
                    lblMsg.Text = "Password has been sent successfully to your associate email account.\n Please check your account.";
                    lblMsg.Style.Add("color", "blue");
                }
                else
                {
                    lblMsg.Text = ConfigurationManager.AppSettings["errormsg"].ToString();
                }
            }
            else
            {
                lblMsg.Text = "Invalid username. Please enter the correct username.";
            }
        }
        catch
        {
            lblMsg.Text = ConfigurationManager.AppSettings["errormsg"].ToString();
        }
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        try
        {
            Response.Redirect("login.aspx",false);
        }
        catch (Exception)
        {
            
            throw;
        }
        
    }
    public static bool SendEmail(string To, string From, string MessageBody, string Subject, bool HTML, string CC)
    {
        try
        {
            string sSMTPServer = "smtp.gmail.com";
            string sUserName = "bhavin4share@gmail.com";
            string sPassword = "FAITH@BMW";
            int iPort = 587;
            SmtpClient smtp = new SmtpClient
            {
                Host = sSMTPServer,
                Port = iPort,
                EnableSsl = true,
                DeliveryMethod = SmtpDeliveryMethod.Network,
                Credentials = new NetworkCredential(sUserName, sPassword), //new NetworkCredential(SendersAddress, SendersPassword),
                Timeout = 30000
            };

            //SmtpClient smtp = new SmtpClient
            //{
            //    Host = "localhost",
            //    Timeout = 30000
            //};
            MailMessage Message = new MailMessage();
            MailAddress FromAddress = new MailAddress(From);
            Message.From = FromAddress;
            Message.To.Add(To);
            if (CC != "")
            {
                Message.CC.Add(CC);
            }
            //Message.Bcc.Add("alpesh4monto@gmail.com");
            Message.Subject = Subject;
            Message.IsBodyHtml = HTML;
            Message.Body = MessageBody;
            smtp.Send(Message);
            return true;
        }
        catch
        {
            return false;
        }

    }
}