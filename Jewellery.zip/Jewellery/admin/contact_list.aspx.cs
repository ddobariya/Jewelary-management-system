﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;

public partial class contact_list : System.Web.UI.Page
{
    string contactType;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (!clsCookies.ExistCookie("pa4ss4f0"))
            {
                Response.Redirect("secure/login.aspx");
            }
            if (Request.QueryString.Get("type") != null)
            {
                contactType = Request.QueryString.Get("type").ToString();
                lblTitle.Text = contactType;
            }
            else
            {
                Response.Redirect("ae_banner.aspx");
            }
            bindContact();
        }
    }
    void bindContact()
    {
        List<uspContactUs_GetAll_Result> vResult;
        vResult = clsContact.GetData_BySearch(1, 10, contactType);
        if (vResult.Count == 0 || vResult == null)
        {
            //no data available
        }
        else
        {
            rptData.DataSource = vResult;
            rptData.DataBind();
        }
    }
    protected void rptData_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "Delete")
        {
            clsContact.ContactUs_Delete(Convert.ToInt32(e.CommandArgument));
            bindContact();
        }
    }
}