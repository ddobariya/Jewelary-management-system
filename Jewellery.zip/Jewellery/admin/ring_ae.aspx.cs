﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;
public partial class admin_ring_ae : System.Web.UI.Page
{
    public static int id;
    public static string sImage;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString.Get("Id") != null)
            {
                id = Convert.ToInt32(Request.QueryString.Get("Id").ToString());
              
                bindData();
            }
            else
            {
                id = 0;
               
            }
        }

    }
    void bindData()
    {
        uspRing_GetById_Result vResult;
        vResult = clsRing.getbyid(id);
        txtProductcode.Text = vResult.sProductCode;
        txtProductname.Text = vResult.sProductName;
        txtInformation.Text = vResult.sInformation;
        txtNoofdiamond.Text = vResult.iNoOfDiamond.ToString();
        txtPolish.Text = vResult.sPolish;
        txtTypes.Text = vResult.sTypes;
        ddlMetal.Text = vResult.sMetal;
        ddlSize.Text = vResult.iRingsize.ToString();
        txtWeight.Text = vResult.sWeight;
        txtQuantity.Text = vResult.iQuantity.ToString();
        txtMrp.Text = vResult.sMRP;
        txtprice.Text = vResult.sPrice;
       // fuImage.
        txtgalley.Text = vResult.sGallery;
        txtinsertdate.Text = vResult.dtInsetDate.ToString();
        if (vResult.bSpecial == true)
        {
            chkSpecial.Checked = true;
        }
        if (vResult.bLatest == true)
        {
            chkLatest.Checked = true;
        }
        if (vResult.bActive == true)
        {
            chkActive.Checked = true;
        }
        if (vResult.bDelivery == true)
        {
            chkDelivery.Checked = true;
        }
       
        

        
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        tblRing vResult = new tblRing();
        vResult.iId = id;
        vResult.sProductCode = txtProductcode.Text;
        vResult.sProductName = txtProductname.Text;
        vResult.sInformation = txtInformation.Text;
        vResult.iNoOfDiamond = Convert.ToInt32(txtNoofdiamond.Text);
        vResult.sPolish = txtPolish.Text;
        vResult.sTypes = txtTypes.Text;
        vResult.sMetal = ddlMetal.SelectedItem.ToString();
        vResult.sWeight = txtWeight.Text;
        vResult.iRingsize = Convert.ToInt32(ddlSize.SelectedItem.ToString());
        vResult.iQuantity = Convert.ToInt32(txtQuantity.Text);
        vResult.sMRP = txtMrp.Text;
        vResult.sPrice = txtprice.Text;
        if (fuImage.FileName.ToString() != "")
        {
            string ext = System.IO.Path.GetExtension(fuImage.PostedFile.FileName);
            if (File.Exists(Server.MapPath(ConfigurationManager.AppSettings["imgRing"].ToString() + fuImage.FileName)))
            {
                File.Delete(Server.MapPath(ConfigurationManager.AppSettings["imgRing"].ToString() + fuImage.FileName));
            }
            vResult.sImage = fuImage.FileName;
            fuImage.SaveAs(Server.MapPath(ConfigurationManager.AppSettings["imgRing"].ToString() + fuImage.FileName));
        }
        else
        {

            vResult.sImage = sImage;
        }
        vResult.sGallery = txtgalley.Text;
        // vResult.sWeight = txtWeight.Text;
        // vResult.sPrice = txtPrice.Text;
        //vResult.dtInsertDate = Convert.ToInt32(txtDtinsertdate.Text);
        //vResult.iQuantity = Convert.ToInt32(txtQuantity.Text);
        // vResult.sType = txtType.Text;
        if (chkDelivery.Checked)
        {
            vResult.bDelivery = true;
        }
        else
        {
            vResult.bDelivery = false;
        }
        if (chkSpecial.Checked)
        {
            vResult.bSpecial = true;
        }
        else
        {
            vResult.bSpecial = false;
        }
        if (chkLatest.Checked)
        {
            vResult.bLatest = true;
        }
        else
        {
            vResult.bLatest = false;
        }
        if (chkActive.Checked)
        {
            vResult.bActive = true;
        }
        else
        {
            vResult.bActive = false;
        }
        clsRing.Ring_AddorEdit(vResult);
        Response.Redirect("ring_list.aspx");
    }
    
}