﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;

public partial class ae_jewellery : System.Web.UI.Page
{
    public static int id;
    public static string sImage;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            if (Request.QueryString.Get("Id") != null)
            {
                id = Convert.ToInt32(Request.QueryString.Get("Id").ToString());
                bindData();
            }
            else
            {
                id = 0;
            }
        }
    }
    void bindData()
    {
        uspBangles_GetById_Result vResult;
        vResult = clsBangels.Bangels_GetById(id);
        txtItemDescription.Text = vResult.sItemdesc;
        sImage = vResult.sImage;
        txtDesignno.Text = vResult.sDesignNo;
        //txt.Text = vResult.sColor;
        txtGold.Text = vResult.sGold;
        //t.Text = vResult.sCountryOrigin;
        txtWeight.Text = vResult.sWeight;
        //txtSh.Text = vResult.sShape;
        txtPrice.Text = vResult.sPrice;
        txtQuantity.Text = vResult.iQuantity.ToString();
        txtType.Text = vResult.sType;
        if (vResult.bSpecial == true)
        {
            chkSpecial.Checked = true;
        }
        if (vResult.bLatest == true)
        {
            chkLatest.Checked = true;
        }
        if (vResult.bActive == true)
        {
            chkActive.Checked = true;
        }
        if (vResult.bDelivery == true)
        {
            chkDelivery.Checked = true;
        }
      
    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        tblBangle vResult = new tblBangle();
        vResult.iId = id;
        vResult.sItemdesc = txtItemDescription.Text;
        if (fuImage.FileName.ToString() != "")
        {
            string ext = System.IO.Path.GetExtension(fuImage.PostedFile.FileName);
            if (File.Exists(Server.MapPath(ConfigurationManager.AppSettings["imgBangles"].ToString() + fuImage.FileName)))
            {
                File.Delete(Server.MapPath(ConfigurationManager.AppSettings["imgBangles"].ToString() + fuImage.FileName));
            }
            vResult.sImage = fuImage.FileName;
            fuImage.SaveAs(Server.MapPath(ConfigurationManager.AppSettings["imgBangles"].ToString() + fuImage.FileName));
        }
        else
        {

            vResult.sImage = sImage;
        }
        vResult.sDesignNo = txtDesignno.Text;
        vResult.sColor = ddlColor.SelectedItem.ToString();
        vResult.sGold = txtGold.Text;
        vResult.sCountryOrigin = ddlCountry.SelectedItem.ToString();
        vResult.sWeight = txtWeight.Text;
        vResult.sPrice = txtPrice.Text;
        //vResult.dtInsertDate = Convert.ToInt32(txtDtinsertdate.Text);
        vResult.iQuantity = Convert.ToInt32(txtQuantity.Text);
        vResult.sType = txtType.Text;
        if (chkDelivery.Checked)
        {
            vResult.bDelivery = true;
        }
        else
        {
            vResult.bDelivery = false;
        }
        if (chkSpecial.Checked)
        {
            vResult.bSpecial = true;
        }
        else
        {
            vResult.bSpecial = false;
        }
        if (chkLatest.Checked)
        {
            vResult.bLatest = true;
        }
        else
        {
            vResult.bLatest = false;
        }
        if (chkActive.Checked)
        {
            vResult.bActive = true;
        }
        else
        {
            vResult.bActive = false;
        }
        clsBangels.Bangels_AddorEdit(vResult);
    }
}