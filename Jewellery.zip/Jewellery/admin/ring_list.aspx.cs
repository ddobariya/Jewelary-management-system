﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;
public partial class admin_ring_list : System.Web.UI.Page
{
    public static int id;
    protected void Page_Load(object sender, EventArgs e)
    {
        binddata();
    }
    void binddata()
    {
        List<uspRing_GetAll_Result> vResult;
        vResult = clsRing.getall();
        rptData.DataSource = vResult;
        rptData.DataBind();
    }
    protected void rptData_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "Edit")
        {
            id = Convert.ToInt32(e.CommandArgument);
            Response.Redirect("ring_ae.aspx?Id=" + e.CommandArgument);



        }
        if (e.CommandName.ToString() == "Delete")
        {
            clsRing.Ring_Delete(Convert.ToInt32(e.CommandArgument));
            binddata();
        }
    }
}