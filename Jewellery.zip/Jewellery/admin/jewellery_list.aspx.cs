﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;

public partial class admin_jewellery_list : System.Web.UI.Page
{
    public static int id;
    protected void Page_Load(object sender, EventArgs e)
    {
        binddata();
    }
    void binddata()
    {
        List<uspBangles_GetAll_Result> vResult;
        vResult = clsBangels.Bangels_GetAll();
        rptData.DataSource = vResult;
        rptData.DataBind();
    }
    protected void rptData_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "Edit")
        {
            id = Convert.ToInt32(e.CommandArgument);
            Response.Redirect("jewellery_ae.aspx?Id=" + e.CommandArgument);



        }
        if (e.CommandName.ToString() == "Delete")
        {
            clsBangels.Bangels_Delete(Convert.ToInt32(e.CommandArgument));
            binddata();
        }
    }
}