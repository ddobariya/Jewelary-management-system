﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using jewelleryModel;
using System.Configuration;
/// <summary>
/// Summary description for clsContactdetail
/// </summary>
public class clsContactdetail
{
	public clsContactdetail()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static void Contactdetail_Delete(int id)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspContactdetail_Delete(id);
    }
    public static void Contactdetail_Add(tblContactdetail tdata)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspContactdetail_Add(tdata.MailingAddress,tdata.PhoneNumber,tdata.EmailAddress,tdata.Website);
    }
    public static List<uspContactdetail_GetAll_Result> Contactdetail_GetAll()
    {

        List<uspContactdetail_GetAll_Result> vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspContactdetail_GetAll().ToList<uspContactdetail_GetAll_Result>();
        return vResult;

    }
    public static uspContactdetail_GetById_Result Contactdetail_GetById(int id)
    {

        uspContactdetail_GetById_Result vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspContactdetail_GetById(id).ToList<uspContactdetail_GetById_Result>().SingleOrDefault();
        return vResult;

    }
    public static void Contactdetail_Update(tblContactdetail tdata)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspContactdetail_Update(tdata.Id, tdata.MailingAddress,tdata.PhoneNumber,tdata.EmailAddress,tdata.Website);
    }
    public static int Contactdetail_AddorEdit(tblContactdetail tdata)
    {
        int iResult = 0;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        iResult = Convert.ToInt32(db.uspContactdetail_AddorEdit(tdata.Id, tdata.MailingAddress, tdata.PhoneNumber,tdata.EmailAddress,tdata.Website).SingleOrDefault());
        return iResult;
    }
}