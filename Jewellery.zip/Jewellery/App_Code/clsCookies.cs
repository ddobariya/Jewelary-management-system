﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
/// <summary>
/// Summary description for clsCookies
/// </summary>
public class clsCookies
{
	public clsCookies()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static string dbConnectionString
    {
        get
        {
            return ConfigurationManager.ConnectionStrings["con1"].ConnectionString;
        }
    }



    public static bool ExistCookie(string Name)
    {
        if (HttpContext.Current.Request.Cookies[Name] == null)
        {
            return false;
        }
        else
        {
            return true;
        }
    }


    public static void CreateCookie(string Name, string Value)
    {
        HttpCookie myCookie = new HttpCookie(Name);
        myCookie.Value = cryptography.EncryptText(Value);
        DateTime dtNow = DateTime.Now;
        TimeSpan tsMinute = new TimeSpan(0, 25, 0);
        myCookie.Expires = dtNow + tsMinute;
        HttpContext.Current.Response.Cookies.Add(myCookie);
    }

    public static void CreateNormalCookie(string Name, string Value)
    {
        HttpCookie myCookie = new HttpCookie(Name);
        myCookie.Value = Value;
        DateTime dtNow = DateTime.Now;
        TimeSpan tsMinute = new TimeSpan(365, 0, 0, 0);
        myCookie.Expires = dtNow + tsMinute;
        HttpContext.Current.Response.Cookies.Add(myCookie);
    }

    public static string GetNormalCookie(string Name)
    {
        if (ExistCookie(Name))
        {
            return HttpContext.Current.Request.Cookies[Name].Value;
        }
        else
        {
            return "";
        }
    }


    public static void SetCookie(string Name, string Value)
    {
        HttpCookie myCookie = HttpContext.Current.Request.Cookies[Name];
        myCookie.Value = cryptography.EncryptText(Value);
        //DateTime ExpDT = Convert.ToDateTime(myCookie["ExpDate"]);
        //myCookie.Values["DealerID"] = cryptography.EncryptText(Value);
        //myCookie.Expires = ExpDT;
        HttpContext.Current.Response.AppendCookie(myCookie);
    }
    public static void SetNormalCookie(string Name, string Value)
    {
        HttpCookie myCookie = HttpContext.Current.Request.Cookies[Name];
        myCookie.Value = Value;
        //DateTime ExpDT = Convert.ToDateTime(myCookie["ExpDate"]);
        //myCookie.Values["DealerID"] = cryptography.EncryptText(Value);
        //myCookie.Expires = ExpDT;
        HttpContext.Current.Response.AppendCookie(myCookie);
    }


    public static void DeleteAllCookie()
    {
        string[] cookies = HttpContext.Current.Request.Cookies.AllKeys;
        foreach (string cookie in cookies)
        {
            HttpContext.Current.Response.Cookies[cookie].Expires = DateTime.Now.AddDays(-1);
        }
    }


    public static string GetCookie(string Name)
    {
        return cryptography.DecryptText(HttpContext.Current.Request.Cookies[Name].Value);
    }

    public static void DeleteCookie(string Name)
    {
        HttpCookie myCookie = new HttpCookie(Name);
        if (myCookie != null)
        {
            myCookie.Expires = DateTime.Now.AddDays(-1d);
            HttpContext.Current.Response.Cookies.Add(myCookie);
        }
    }
}