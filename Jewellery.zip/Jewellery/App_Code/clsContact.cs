﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using jewelleryModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

/// <summary>
/// Summary description for clsContact
/// </summary>
public class clsContact
{
	public clsContact()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static int AddContactUs_data(tblContactU tdata)
    {
        int iResult = 0;
        try
        {
            using (jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString))
            {
                iResult = Convert.ToInt32(db.uspContactUs_Add(tdata.sName, tdata.sEmail, tdata.sPhone, tdata.sAddress, tdata.sZip, tdata.sCountry, tdata.sSubject, tdata.sQuery, tdata.sFile, tdata.iUserID, tdata.sType).SingleOrDefault()); ;
            }
        }
        catch
        {
            iResult = 0;
        }
        return iResult;
    }
    public static List<uspContactUs_GetAll_Result> GetData_BySearch(int iPageNo, int iPageSize, string sType)
    {
        List<uspContactUs_GetAll_Result> vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspContactUs_GetAll(iPageNo, iPageSize, sType).ToList<uspContactUs_GetAll_Result>();
        return vResult;
    }
    public static List<uspContactUs_GetByID_Result> GetContactUs_GetByID(int iContactId)
    {
        List<uspContactUs_GetByID_Result> vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspContactUs_GetByID(iContactId).ToList<uspContactUs_GetByID_Result>();
        return vResult;
    }
    public static void ContactUs_Delete(int id)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspContactUs_Delete(id);
    }
}