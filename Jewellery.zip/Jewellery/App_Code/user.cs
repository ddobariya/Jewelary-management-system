﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using jewelleryModel;
using System.Configuration;
//using nevadaautoguide_dataaccess.App_Code.DAL;


/// <summary>
/// Summary description for user
/// </summary>
public class user
{
	public user()
	{
		//
		// TODO: Add constructor logic here
		//
	}


    //public static  List<uspUser_GetAll_Result> GetAll(short DealerID, int PageNumber, int PageSize, out int TotalCount, out int TotalPage)
    //{
    //    List<uspUser_GetAll_Result> vResult = null;
    //    TotalCount = 0;
    //    TotalPage = 0;
    //    try
    //    {
    //        System.Data.Objects.ObjectParameter pTotalCount = new System.Data.Objects.ObjectParameter("TotalCount", typeof(short));
    //        System.Data.Objects.ObjectParameter pTotalPages = new System.Data.Objects.ObjectParameter("TotalPages", typeof(short));

    //        using (nevedaautoguideEntities DB = new nevedaautoguideEntities(neveda.NevedaConnectionString))
            
    //        {
    //            vResult = DB.uspUser_GetAll(DealerID, PageNumber, PageSize, pTotalCount, pTotalPages).ToList<uspUser_GetAll_Result>();                
    //            if (pTotalCount.Value != DBNull.Value)
    //                TotalCount = Convert.ToInt16(pTotalCount.Value);
    //            else
    //                TotalCount = 0;

    //            if (pTotalPages.Value != DBNull.Value)
    //                TotalPage = Convert.ToInt16(pTotalPages.Value);
    //            else
    //                TotalPage = 0;
    //        }
    //    }
    //    catch
    //    {

    //    }
    //    return vResult;
    //}

    //public static tblUser Get(short ID)
    //{
    //    tblUser Obj = null;        
    //    try
    //    {
    //        using (nevedaautoguideEntities DB = new nevedaautoguideEntities(neveda.NevedaConnectionString))
    //        {
    //            Obj = DB.uspUser_Get(ID).SingleOrDefault();
    //        }
    //    }
    //    catch
    //    {

    //    }
    //    return Obj;
    //}

    //public static tblUser GetFirstDealerUser(short DealerID)
    //{
    //    tblUser Obj = null;
    //    try
    //    {
    //        using (nevedaautoguideEntities DB = new nevedaautoguideEntities(neveda.NevedaConnectionString))
    //        {
    //            Obj = DB.uspUser_Get_FirstDealerUser(DealerID).SingleOrDefault();
    //        }
    //    }
    //    catch
    //    {

    //    }
    //    return Obj;
    //}


    public static uspUser_Get_PassWord_Result Get_PassWord(string UserName)
    {
        uspUser_Get_PassWord_Result Obj = null;
        try
        {
            using (jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString))
            {
                Obj = db.uspUser_Get_PassWord(UserName).SingleOrDefault();
            }
        }
        catch
        {

        }
        return Obj;
    }
    public static uspUser_Get_UserName_Result Get_UserName(string Email)
    {
        uspUser_Get_UserName_Result Obj = null;
        try
        {
            using (jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString))
            {
                Obj = db.uspUser_Get_UserName(Email).SingleOrDefault();
            }
        }
        catch
        {

        }
        return Obj;
    }

    public static uspUser_Validate_Result Validate(string UserName, string PassWord)
    {
        uspUser_Validate_Result Obj = null;
        try
        {
            using (jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString))
            {
                Obj = db.uspUser_Validate(UserName.Trim(), PassWord.Trim()).SingleOrDefault();
            }
        }
        catch
        {

        }
        return Obj;
    }

    //public static short Add(tblUser Obj)
    //{
    //    short iUserID = -1;
    //    try
    //    {
    //        using (nevedaautoguideEntities DB = new nevedaautoguideEntities(neveda.NevedaConnectionString))
    //        {
    //            Obj.FirstName = Obj.FirstName.Trim();
    //            Obj.LastName = Obj.LastName.Trim() == "" ? null : Obj.LastName.Trim();
    //            Obj.Email = Obj.Email.Trim();
    //            Obj.UserName = Obj.UserName.Trim();
    //            Obj.PassWord = Obj.PassWord.Trim();
    //            iUserID = DB.uspUser_Add(Obj.DealerID, Obj.FirstName, Obj.LastName, Obj.Email, Obj.UserName, Obj.PassWord).SingleOrDefault().GetValueOrDefault();
    //        }
    //    }
    //    catch
    //    {

    //    }
    //    return iUserID;
    //}


    //public static short Edit(tblUser Obj)
    //{
    //    short iUserID = -1;
    //    try
    //    {
    //        using (nevedaautoguideEntities DB = new nevedaautoguideEntities(neveda.NevedaConnectionString))
    //        {
    //            Obj.FirstName = Obj.FirstName.Trim();
    //            Obj.LastName = Obj.LastName.Trim() == "" ? null : Obj.LastName.Trim();
    //            Obj.Email = Obj.Email.Trim();
    //            Obj.UserName = Obj.UserName.Trim();
    //            Obj.PassWord = Obj.PassWord.Trim();
    //            iUserID = DB.uspUser_Edit(Obj.UserID, Obj.FirstName, Obj.LastName, Obj.Email, Obj.UserName, Obj.PassWord).SingleOrDefault().GetValueOrDefault();
    //        }
    //    }
    //    catch
    //    {

    //    }
    //    return iUserID;
    //}

    //public static short Exist(tblUser Obj)
    //{
    //    short iUserID = -1;
    //    try
    //    {
    //        using (nevedaautoguideEntities DB = new nevedaautoguideEntities(neveda.NevedaConnectionString))
    //        {
    //            Obj.Email = Obj.Email.Trim();
    //            Obj.UserName = Obj.UserName.Trim();
    //            iUserID = DB.uspUser_Exist(Obj.DealerID, Obj.Email, Obj.UserName).SingleOrDefault().GetValueOrDefault();
    //        }
    //    }
    //    catch
    //    {

    //    }
    //    return iUserID;
    //}

    //public static int Delete(short ID)
    //{
    //    int iResponse = -1;
    //    try
    //    {
    //        using (nevedaautoguideEntities DB = new nevedaautoguideEntities(neveda.NevedaConnectionString))
    //        {
    //            iResponse = DB.uspUser_Delete(ID);
    //        }
    //    }
    //    catch
    //    {

    //    }
    //    return iResponse;
    //}




}
