﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using jewelleryModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
/// <summary>
/// Summary description for clsRing
/// </summary>
public class clsRing
{
	public clsRing()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static void Ring_Add(tblRing tdata)
    {
        jewelleryEntities db=new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspRing_Insert(tdata.sProductCode, tdata.sProductName, tdata.sInformation, tdata.iNoOfDiamond, tdata.sPolish, tdata.sTypes, tdata.sMetal, tdata.sWeight, tdata.iRingsize, tdata.iQuantity, tdata.sMRP, tdata.sPrice,tdata.sImage,tdata.sGallery, tdata.bDelivery, tdata.bSpecial, tdata.bLatest, tdata.bActive);
    }

    public static void Ring_Delete(int id)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspRing_Delete(id);
    }
    public static List<uspRing_GetAll_Result> getall()
    {

        List<uspRing_GetAll_Result> vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspRing_GetAll().ToList<uspRing_GetAll_Result>();
        return vResult;

    }
    public static uspRing_GetById_Result getbyid(int id)
    {

        uspRing_GetById_Result vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspRing_GetById(id).ToList<uspRing_GetById_Result>().SingleOrDefault();
        return vResult;
    }
    public static void Ring_update(tblRing tdata)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspRing_Update(tdata.iId, tdata.sProductCode, tdata.sProductName, tdata.sInformation, tdata.iNoOfDiamond, tdata.sPolish, tdata.sTypes, tdata.sMetal, tdata.sWeight, tdata.iRingsize, tdata.iQuantity, tdata.sMRP, tdata.sPrice, tdata.sImage, tdata.sGallery, tdata.dtInsetDate, tdata.bDelivery, tdata.bSpecial, tdata.bLatest, tdata.bActive);
    }
    public static int Ring_AddorEdit(tblRing tdata)
    {
        int iResult = 0;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        iResult = Convert.ToInt32(db.uspRing_AddorEdit(tdata.iId, tdata.sProductCode, tdata.sProductName, tdata.sInformation, tdata.iNoOfDiamond, tdata.sPolish, tdata.sTypes, tdata.sMetal, tdata.sWeight, tdata.iRingsize, tdata.iQuantity, tdata.sMRP, tdata.sPrice, tdata.sImage, tdata.sGallery, tdata.bDelivery, tdata.bSpecial, tdata.bLatest, tdata.bActive).SingleOrDefault());
        return iResult;
    }
    public static DataTable Ring_GetAll_dev(string val, bool bActive, int ipageno, int ipagesize, string vOrder)
    {
        // string sqlcon = ConfigurationManager.ConnectionStrings["ePortalEntities"].ConnectionString;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con1"].ConnectionString);
        DataTable dt = new DataTable();
        SqlCommand cmd = new SqlCommand("uspRing_GetAll_dev", con);
        DataTable result;
        //try
        //{
        con.Open();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@value", val);
        cmd.Parameters.AddWithValue("@bActive", bActive);
        cmd.Parameters.AddWithValue("@ipageno", ipageno);
        cmd.Parameters.AddWithValue("@ipagesize", ipagesize);
        //cmd.Parameters.AddWithValue("@TotalPages", TotalPages);
        cmd.Parameters.AddWithValue("@vOrder", vOrder);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        result = dt;
        //}
        //catch
        //{
        //    result = null;
        //}
        //finally
        //{
        con.Close();
        con.Dispose();
        cmd.Dispose();
        //}
        return result;
    }
    public static int Ring_GetCount()
    {
        int iResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        iResult = Convert.ToInt32(db.uspRing_Count("All", true).SingleOrDefault());
        return iResult;
    }
}