﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using jewelleryModel;
using System.Configuration;
/// <summary>
/// Summary description for clsFaq
/// </summary>
public class clsFaq
{
	public clsFaq()
	{
		//
		// TODO: Add constructor logic here
		//
    }
    public static void Faq_Delete(int id)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspSubscribe_Delete(id);
    }
    public static void Faq_Add(tblFaq tdata)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspFaq_Insert(tdata.sQuestion,tdata.sAnswer,tdata.bActive,tdata.sUserName,tdata.sEmail);
    }

    public static List<uspFaq_GetAll_Result> Faq_GetAll()
    {

        List<uspFaq_GetAll_Result> vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspFaq_GetAll().ToList<uspFaq_GetAll_Result>();
        return vResult;

    }
    public static uspFaq_GetById_Result Faq_GetById(int id)
    {

        uspFaq_GetById_Result vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspFaq_GetById(id).ToList<uspFaq_GetById_Result>().SingleOrDefault();
        return vResult;

    }
    public static void Faq_Update(tblFaq tdata)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspFaq_Update(tdata.iFaqId,tdata.sQuestion, tdata.sAnswer, tdata.bActive, tdata.sUserName, tdata.sEmail);
    }
    public static int Faq_AddorEdit(tblFaq tdata)
    {
        int iResult = 0;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        iResult = Convert.ToInt32(db.uspFaq_AddorEdit(tdata.iFaqId,tdata.sQuestion,tdata.sAnswer,tdata.bActive,tdata.sUserName,tdata.sEmail).SingleOrDefault());
        return iResult;
    }

}