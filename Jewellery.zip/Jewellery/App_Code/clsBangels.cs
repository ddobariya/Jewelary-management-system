﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using jewelleryModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
/// <summary>
/// Summary description for clsBangels
/// </summary>
public class clsBangels
{
	public clsBangels()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static void Bangels_Add(tblBangle tdata)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspBangles_Insert(tdata.sItemdesc,tdata.sImage, tdata.sDesignNo, tdata.sColor, tdata.sGold, tdata.sCountryOrigin, tdata.sWeight, tdata.sShape, tdata.sPrice, tdata.dtInsertDate, tdata.iQuantity, tdata.sType,tdata.bDelivery, tdata.bSpecial, tdata.bLatest, tdata.bActive);
    }
    public static List<uspBangles_GetAll_Result> Bangels_GetAll()
    {

        List<uspBangles_GetAll_Result> vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspBangles_GetAll().ToList<uspBangles_GetAll_Result>();
        return vResult;

    }
    public static uspBangles_GetById_Result Bangels_GetById(int id)
    {

        uspBangles_GetById_Result vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspBangles_GetById(id).ToList<uspBangles_GetById_Result>().SingleOrDefault();
        return vResult;

    }
    public static void Bangels_Delete(int id)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspBangles_Delete(id);
    }
    public static void Bangels_Update(tblBangle tdata)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspBangles_Update(tdata.iId, tdata.sItemdesc, tdata.sImage, tdata.sDesignNo, tdata.sColor, tdata.sGold, tdata.sCountryOrigin, tdata.sWeight, tdata.sShape, tdata.sPrice, tdata.dtInsertDate, tdata.iQuantity, tdata.sType, tdata.bDelivery, tdata.bSpecial, tdata.bLatest, tdata.bActive);
    }
    public static int Bangels_AddorEdit(tblBangle tdata)
    {
        int iResult = 0;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        iResult = Convert.ToInt32(db.uspBangels_AddorEdit(tdata.iId, tdata.sItemdesc, tdata.sImage, tdata.sDesignNo, tdata.sColor, tdata.sGold, tdata.sCountryOrigin, tdata.sWeight, tdata.sShape, tdata.sPrice, tdata.dtInsertDate, tdata.iQuantity, tdata.sType, tdata.bDelivery, tdata.bSpecial, tdata.bLatest, tdata.bActive).SingleOrDefault());
        return iResult;
    }
    public static DataTable Bangles_GetAll_dev(string val, bool bActive, int ipageno, int ipagesize, string vOrder)
    {
       // string sqlcon = ConfigurationManager.ConnectionStrings["ePortalEntities"].ConnectionString;
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["con1"].ConnectionString);
        DataTable dt = new DataTable();
        SqlCommand cmd = new SqlCommand("uspBangles_GetAll_dev", con);
        DataTable result;
        //try
        //{
        con.Open();
        cmd.CommandType = CommandType.StoredProcedure;
        cmd.Parameters.AddWithValue("@value", val);
        cmd.Parameters.AddWithValue("@bActive", bActive);
        cmd.Parameters.AddWithValue("@ipageno", ipageno);
        cmd.Parameters.AddWithValue("@ipagesize", ipagesize);
        //cmd.Parameters.AddWithValue("@TotalPages", TotalPages);
        cmd.Parameters.AddWithValue("@vOrder", vOrder);
        SqlDataAdapter da = new SqlDataAdapter(cmd);
        da.Fill(dt);
        result = dt;
        //}
        //catch
        //{
        //    result = null;
        //}
        //finally
        //{
        con.Close();
        con.Dispose();
        cmd.Dispose();
        //}
        return result;
    }
    public static int Bangles_GetCount()
    {
        int iResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        iResult = Convert.ToInt32(db.uspBangles_Count("All", true).SingleOrDefault());
        return iResult;
    }
}