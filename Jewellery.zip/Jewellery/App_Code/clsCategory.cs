﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using jewelleryModel;
using System.Configuration;


/// <summary>
/// Summary description for clsCategory
/// </summary>
public class clsCategory
{
	public clsCategory()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static void Category_Add(tblCategory tdata)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspCategory_AddorEdit(tdata.iCategory,tdata.sName);
    }
    public static List<uspCategory_GetAll_Result> Category_GetAll()
    {

        List<uspCategory_GetAll_Result> vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspCategory_GetAll().ToList<uspCategory_GetAll_Result>();
        return vResult;

    }
    public static uspCategory_GetById_Result Category_GetById(int id)
    {

        uspCategory_GetById_Result vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspCategory_GetById(id).SingleOrDefault();
        return vResult;

    }
    public static void Category_Delete(int id)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspCategory_Delete(id);
    }
    public static void Category_Update(tblCategory tdata)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspCategory_update(tdata.iCategory,tdata.sName);
    }
    public static int Category_AddorEdit(tblCategory tdata)
    {
        int iResult = 0;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        iResult = Convert.ToInt32(db.uspCategory_AddorEdit(tdata.iCategory,tdata.sName).SingleOrDefault());
        return iResult;
    }
    public static List<uspCategory_Category_Result> Category_GetAll_Category()
    {

        List<uspCategory_Category_Result> vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        //vResult = db.uspCategory_Ca.ToList<uspCategory_Category_Result>();
        vResult = db.uspCategory_Category("temp").ToList<uspCategory_Category_Result>();
        return vResult;

    }
}