﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using jewelleryModel;
using System.Configuration;

/// <summary>
/// Summary description for clsSubscribe
/// </summary>
public class clsSubscribe
{
	public clsSubscribe()
	{
		//
		// TODO: Add constructor logic here
		//
	}
    public static void Subscribe_Delete(int id)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspSubscribe_Delete(id);
    }
    public static void Subscribe_Add(tblSubscribe tdata)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspSubscribe_Add(tdata.sEmail,tdata.bActive);
    }
    public static List<uspSubscribe_GetAll_Result> Subscribe_GetAll()
    {

        List<uspSubscribe_GetAll_Result> vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspSubscribe_GetAll(true).ToList<uspSubscribe_GetAll_Result>();
        return vResult;

    }
    public static uspSubscribe_GetById_Result Subscribe_GetById(int id)
    {

        uspSubscribe_GetById_Result vResult;
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        vResult = db.uspSubscribe_GetById(id).ToList<uspSubscribe_GetById_Result>().SingleOrDefault();
        return vResult;

    }
    public static void Subscribe_Update(tblSubscribe tdata)
    {
        jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
        db.uspSubscribe_Update(tdata.Id,tdata.sEmail, tdata.bActive);
    }
    //public static int Subscribe_AddorEdit(tblSubscribe tdata)
    //{
    //    int iResult = 0;
    //    jewelleryEntities db = new jewelleryEntities(ConfigurationManager.ConnectionStrings["jewelleryEntities"].ConnectionString);
    //    iResult = Convert.ToInt32(db.uspSubscribe_AddorEdit(tdata.Id,tdata.sEmail, tdata.bActive).SingleOrDefault());
    //    return iResult;
    //}

}