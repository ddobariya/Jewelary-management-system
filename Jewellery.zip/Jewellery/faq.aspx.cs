﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;

public partial class faq : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        databind();
    }
    void databind()
    {

        List<uspFaq_GetAll_Result> vResult = null;
        vResult = clsFaq.Faq_GetAll();
        rpFaq.DataSource = vResult;

        rpFaq.DataBind();

    }
}