(function ($) {
    "use strict";

    $('.ct-js-colorSelector').colorselector();

})(jQuery);