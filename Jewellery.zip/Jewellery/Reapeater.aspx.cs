﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;
using System.Configuration;
public partial class Reapeater : System.Web.UI.Page
{
    public static int id;
    protected void Page_Load(object sender, EventArgs e)
    {
        binddata();
    }
    void binddata()
    {
        List<uspRing_GetAll_Result> vResult;
        vResult = clsRing.getall();
        repeater.DataSource = vResult;
        repeater.DataBind();
    }
    protected void repeater_ItemCommand(object source, RepeaterCommandEventArgs e)
    {
        if (e.CommandName.ToString() == "Edit")
        {
            id = Convert.ToInt32(e.CommandArgument);
            uspRing_GetById_Result vResult;
            vResult = clsRing.getbyid(id);
            txtpcode.Text = vResult.sProductCode;
            txtpname.Text = vResult.sProductName;
            txtinfo.Text = vResult.sInformation;
            txtNoofdiamd.Text = vResult.iNoOfDiamond.ToString();
            txtPlish.Text = vResult.sPolish;
            txttype.Text = vResult.sTypes;
            txtmtal.Text = vResult.sMetal;
            txtWigh.Text = vResult.sWeight;
            txtRig.Text = vResult.iRingsize.ToString();
            txtQun.Text = vResult.iQuantity.ToString();
            txtMrp.Text = vResult.sMRP;
            txtPrices.Text = vResult.sPrice;
            txtgallerys.Text = vResult.sGallery;
            //txtDate.Text=vResult.dtInsetDate;

        }
        else if (e.CommandName.ToString() == "Delete")
        {
            clsRing.Ring_Delete(Convert.ToInt32(e.CommandArgument));
            //  binddata();
        }
        
    }
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        tblRing tdata = new tblRing();
        tdata.iId = id;
        tdata.sProductCode = txtpcode.Text;
        tdata.sProductName = txtpname.Text;
        tdata.sInformation = txtinfo.Text;
        tdata.iNoOfDiamond = Convert.ToInt32(txtNoofdiamd.Text);
        tdata.sPolish = txtPlish.Text;
        tdata.sTypes = txttype.Text;
        tdata.sMetal = txtmtal.Text;
        tdata.sWeight = txtWigh.Text;
        tdata.iRingsize =  Convert.ToInt32(txtRig.Text);
        tdata.iQuantity = Convert.ToInt32(txtQun.Text);
        tdata.sMRP = txtMrp.Text;
        tdata.sPrice = txtPrices.Text;
        tdata.sGallery = txtgallerys.Text;
        tdata.dtInsetDate = DateTime.Now;

        
        clsRing.Ring_update(tdata);
    }
}