﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;
using System.Configuration;
public partial class RingForm : System.Web.UI.Page
{
    public static string sImage;
    public static int id;
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        tblRing vResult = new tblRing();
        vResult.sProductCode = txtProductcode.Text;
        vResult.sProductName = txtProductname.Text;
        vResult.sInformation = txtInformation.Text;
        vResult.iNoOfDiamond = Convert.ToInt32(txtNoofdiamond.Text);
        vResult.sPolish = txtPolish.Text;
        vResult.sTypes = txtTypes.Text;
        vResult.sMetal = ddlMetal.SelectedItem.ToString();
       
        vResult.sWeight = txtWeight.Text;
        vResult.iRingsize = Convert.ToInt32(ddlSize.SelectedItem.ToString());
        vResult.iQuantity = Convert.ToInt32(txtQuantity.Text.ToString());
        vResult.sMRP = txtmrp.Text;
        vResult.sPrice = txtPrice.Text;
        vResult.sGallery = txtGallery.Text;
        if (fuImage.FileName == "")
        {
            vResult.sImage = sImage;
        }
        else
        {
            vResult.sImage = fuImage.FileName;
        }
        vResult.dtInsetDate = DateTime.Now;
        if (chkDelivery.Checked)
        {
            vResult.bDelivery = true;
        }
        else
        {
            vResult.bDelivery = false;
        }
        if (chkSpecial.Checked)
        {
            vResult.bSpecial = true;
        }
        else
        {
            vResult.bSpecial = false;
        }
        if (chkLatest.Checked)
        {
            vResult.bLatest = true;
        }
        else
        {
            vResult.bLatest = false;
        }
        if (chkActive.Checked)
        {
            vResult.bActive = true;
        }
        else
        {
            vResult.bActive = false;
        }

        
        clsRing.Ring_Add(vResult);

    }
}