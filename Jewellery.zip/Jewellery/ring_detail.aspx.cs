﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using jewelleryModel;
using System.Configuration;
public partial class ring_detail : System.Web.UI.Page
{
    public static int id;
    protected void Page_Load(object sender, EventArgs e)
    {
        id = Convert.ToInt32(Request.QueryString.Get("id").ToString());
        binddata();
    }
    void binddata()
    {
        uspRing_GetById_Result vResult = null;
        vResult = clsRing.getbyid(id);
        lbldescription.Text = vResult.sProductName;
        lblProductcode.Text = vResult.sProductCode;
        lblProcuctname.Text = vResult.sProductName;
        lblNoofdiamonds.Text = vResult.iNoOfDiamond.ToString();
        lblInfo.Text = vResult.sInformation;
        lblPolish.Text = vResult.sPolish;
        lblTypes.Text = vResult.sTypes;
        lblMetal.Text = vResult.sMetal;
        lblWeight.Text = vResult.sWeight;
        lblRsize.Text = vResult.iRingsize.ToString();
        lblQuantity.Text = vResult.iQuantity.ToString();
        lblMrp1.Text = vResult.sMRP;
        lblprice1.Text = vResult.sPrice;
        lblImg.Text = vResult.sImage;
        if (vResult.bDelivery == true)
        {
            lblDelivery.Text = "(Free Delivery)";
        }
        else
        {
            lblDelivery.Text = "";
        }
        // lblcolor.Text = vResult.sColor;
    }
}